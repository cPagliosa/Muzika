import React from 'react';
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../app/store';
import { removeMusicFromPlaylist } from './playlistsSlice';

export default function PlaylistDetails() {
  const { id } = useParams();
  const playlist = useSelector((s: RootState) => s.playlists.items.find(p => p.id === id));
  const user = useSelector((s: RootState) => s.auth.user);
  const dispatch = useDispatch();

  if (!playlist) return <div>Playlist não encontrada.</div>;
  if (playlist.usuarioId !== user?.id) return <div>Acesso negado — esta playlist pertence a outro usuário.</div>;

  const handleRemove = (musicId: string) => {
    if (!confirm('Remover música?')) return;
    dispatch(removeMusicFromPlaylist({ playlistId: id!, musicId }));
  };

  return (
    <div>
      <h2>{playlist.nome}</h2>
      <ul>
        {playlist.musicas.map(m => (
          <li key={m.id}>
            {m.nome} — {m.artista} ({m.ano})
            <button onClick={() => handleRemove(m.id)}>Remover</button>
          </li>
        ))}
      </ul>
      <p>Use a busca de músicas para adicionar (tela /musicas).</p>
    </div>
  );
}